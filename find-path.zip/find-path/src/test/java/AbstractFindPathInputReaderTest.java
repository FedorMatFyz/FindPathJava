import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AbstractFindPathInputReaderTest {

    @Test
    void test(){
        var abstractFindPathInputReaderTest =  new FindPathInputReaderStdIn();
        List<Integer> start = Arrays.asList(1,2);
        List<Integer> end = Arrays.asList(11,26);
        ArrayList<ArrayList<Character>> maze = new ArrayList<>();
        String str_maze = ".................................... " +
                "..S...#......................#...... " +
                "......#......................#...... " +
                ".............................#...... " +
                ".................................... " +
                ".................................... " +
                "..............#..................... " +
                "............#....................... " +
                "..........#......................... " +
                ".................................... " +
                ".....................#..........#... " +
                ".....................#....X.....#... " +
                ".....................#..........#... " +
                "....................................";
        List<String> listMaze = Arrays.asList(str_maze.split("\\s* \\s*"));
        for (String s : listMaze) {
            ArrayList<Character> line = new ArrayList<Character>();
            for (int x = 0; x < s.length(); x++) {
                Character ch = s.charAt(x);
                line.add(ch);
            }
            maze.add(line);
            }

        assertEquals("rrrddrrrrrrrrrrrrrrdrdrdrdrdrdrdrd", abstractFindPathInputReaderTest.AStar(maze, start, end));




        maze = new ArrayList<>();
        str_maze = ".....................#.............. " +
                "..S...#..............#.......#...... " +
                "......#..............#.......#...... " +
                ".....................#.......#...... " +
                ".....................#.............. " +
                ".....................#.............. " +
                "..............#......#.............. " +
                "............#........#.............. " +
                "..........#..........#.............. " +
                ".....................#.............. " +
                ".....................#..........#... " +
                ".....................#....X.....#... " +
                ".....................#..........#... " +
                ".....................#..............";
        listMaze = Arrays.asList(str_maze.split("\\s* \\s*"));
        for (String s : listMaze) {
            ArrayList<Character> line = new ArrayList<Character>();
            for (int x = 0; x < s.length(); x++) {
                Character ch = s.charAt(x);
                line.add(ch);
            }
            maze.add(line);
        }

        assertEquals("There is no way in this maze", abstractFindPathInputReaderTest.AStar(maze, start, end));
    }
}
