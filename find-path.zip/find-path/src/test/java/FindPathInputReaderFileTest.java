import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class FindPathInputReaderFileTest {

    @Test
    void test(){
        var findPathInputReaderFile = new FindPathInputReaderFile("maze.txt");
        assertEquals("rrrddrrrrrrrrrrrrrrdrdrdrdrdrdrdrd", findPathInputReaderFile.FindPath());


        findPathInputReaderFile = new FindPathInputReaderFile("big_maze.txt");
        assertEquals("rdrdrdrdrdrdrddrrdrdrrrrrrrruuuuuuuuurrddddddddrrurrrrrrruuuuuuuuurrddddddddddddddrrrrrrrrrrddllllllllldlddddddddddllllllulu", findPathInputReaderFile.FindPath());
    }
}
