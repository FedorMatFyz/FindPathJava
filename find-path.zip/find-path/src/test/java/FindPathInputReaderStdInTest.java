import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;

import static org.junit.jupiter.api.Assertions.*;

public class FindPathInputReaderStdInTest {

    private ByteArrayInputStream testIn;

    private void provideInput(String data) {
        testIn = new ByteArrayInputStream(data.getBytes());
        System.setIn(testIn);
    }

    @Test
    void test(){
        var findPathInputReaderStdIn = new FindPathInputReaderStdIn();
        String maze_for_test = ".................................... ..S...#......................#...... ......#......................#...... .............................#...... .................................... .................................... ..............#..................... ............#....................... ..........#......................... .................................... .....................#..........#... .....................#....X.....#... .....................#..........#... ....................................";
        provideInput(maze_for_test);
        assertEquals("rrrddrrrrrrrrrrrrrrdrdrdrdrdrdrdrd", findPathInputReaderStdIn.FindPath());

        maze_for_test = "...S................................ ";
        provideInput(maze_for_test);
        assertEquals("Wrong maze", findPathInputReaderStdIn.FindPath());

        maze_for_test = "...S.......................XX....... ";
        provideInput(maze_for_test);
        assertEquals("Wrong maze", findPathInputReaderStdIn.FindPath());

        maze_for_test = ".............................X...... ";
        provideInput(maze_for_test);
        assertEquals("Wrong maze", findPathInputReaderStdIn.FindPath());

        maze_for_test = "...SS.......................X....... ";
        provideInput(maze_for_test);
        assertEquals("Wrong maze", findPathInputReaderStdIn.FindPath());
    }
}
