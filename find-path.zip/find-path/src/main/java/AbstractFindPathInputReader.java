import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

abstract class AbstractFindPathInputReader {
    public abstract String FindPath();

    public String AStar(ArrayList<ArrayList<Character>> ArrayListMaze, List<Integer> start, List<Integer> end) {
        Node start_node = new Node(null, start);
        start_node.g = 0;
        start_node.h = 0;
        start_node.f = 0;
        Node end_node = new Node(null, end);
        end_node.g = 0;
        end_node.h = 0;
        end_node.f = 0;

        ArrayList<Node> open_list = new ArrayList<Node>();
        ArrayList<Node> closed_list = new ArrayList<Node>();

        open_list.add(start_node);

        while (open_list.size() > 0){
            Node current_node = open_list.get(0);
            int current_index = 0;
            for (int i = 0; i < open_list.size(); i++){
                if(open_list.get(i).f  < current_node.f){
                    current_node = open_list.get(i);
                    current_index = i;
                }
            }
            closed_list.add(current_node);
            open_list.remove(current_index);
            if (current_node.eq(end_node)){
                return current_node.path;
//                ArrayList<List<Integer>> path = new ArrayList<List<Integer>>() ;
//                Node current = current_node;
//                while (!current.eq(start_node)){
//                    path.add(current.position);
//                    current = current.parent;
//                }
//                path.add(start_node.position);
//                return path.toString();

            }
            ArrayList<Node> children = new ArrayList<Node>();
            ArrayList<int[]> positions =  new ArrayList<int[]>();
            int[] arr1 = {0, -1, 1};
            int[] arr2 = {0, 1, 2};
            int[] arr3 = {-1, 0, 3};
            int[] arr4 = {1, 0, 4};
            positions.add(arr1);
            positions.add(arr2);
            positions.add(arr3);
            positions.add(arr4);
            for(int[] new_position: positions){

                int[] node_position = {current_node.position.get(0) + new_position[0], current_node.position.get(1) + new_position[1]};
                if(node_position[0] > ArrayListMaze.size()-1 || node_position[0] < 0 || node_position[1] > ArrayListMaze.get(0).size() -1 || node_position[1] < 0)
                    continue;
                if(ArrayListMaze.get(node_position[0]).get(node_position[1]).equals('#'))
                    continue;
                Node new_node = new Node(current_node, Arrays.asList(node_position[0], node_position[1]));
                switch (new_position[2]){
                    case 1:
                        new_node.path = current_node.path + "l";
                        break;
                    case 2:
                        new_node.path = current_node.path + "r";
                        break;
                    case 3:
                        new_node.path = current_node.path + "u";
                        break;
                    case 4:
                        new_node.path = current_node.path + "d";
                        break;
                }

                children.add(new_node);
            }
            for(Node child : children){
                boolean to_start = false;
                for(Node closed_child: closed_list){
                    if(child.eq(closed_child)){
                        to_start = true;
                        break;
                    }
                }
                if(to_start) continue;

                child.g = current_node.g + 1;
                child.h = ((child.position.get(0) - end_node.position.get(0)) * (child.position.get(0) - end_node.position.get(0))) + ((child.position.get(1) - end_node.position.get(1)) * (child.position.get(1) - end_node.position.get(1)));
                child.f = child.g + child.h;

                for(Node open_node: open_list){
                    if(child.eq(open_node) & child.g > open_node.g){
                        to_start = true;
                        break;
                    }
                }
                if(to_start) continue;
                open_list.add(child);
            }
        }
        return "There is no way in this maze";
    }
}
