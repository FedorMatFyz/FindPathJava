import java.util.List;
import java.util.Objects;

public class Node {
    int g = 0;
    int h = 0;
    int f = 0;
    String path = "";
    List<Integer> position;
    Node parent;

    public Node(Node parent , List<Integer> position ){
        this.parent = parent;
        this.position = position;
    }

    public boolean eq(Node o) {
            return o.position.get(0).equals(this.position.get(0)) & o.position.get(1).equals(this.position.get(1)) ;
    }
}
