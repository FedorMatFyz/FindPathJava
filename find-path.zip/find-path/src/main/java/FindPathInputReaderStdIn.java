import java.util.*;
public class FindPathInputReaderStdIn extends AbstractFindPathInputReader{
    public FindPathInputReaderStdIn (){


    }
    public String FindPath(){
        Scanner sc= new Scanner(System.in);
        System.out.print("Enter a maze: ");
        String maze= sc.nextLine();
        List<String> listMaze = Arrays.asList(maze.split("\\s* \\s*"));
        int y = 0;
        List<Integer> start = new ArrayList<Integer>();
        List<Integer> end = new ArrayList<Integer>();
        ArrayList<ArrayList<Character>> ArrayListMaze = new ArrayList<ArrayList<Character>>();
        for (String s : listMaze) {
            ArrayList<Character> line = new ArrayList<Character>();
            for (int x = 0; x < s.length(); x++) {
                Character ch = s.charAt(x);
                line.add(ch);
                if(ch.equals('S')){
                    if(!start.isEmpty()){
                        return "Wrong maze";
                    }
                    start.add(y);
                    start.add(x);
                }
                if(ch.equals('X')){
                    if(!end.isEmpty()){
                        return "Wrong maze";
                    }
                    end.add(y);
                    end.add(x);
                }
            }
            ArrayListMaze.add(line);
            y++;
        }
        if(start.isEmpty() || end.isEmpty()){
            return "Wrong maze";
        }

        return AStar(ArrayListMaze, start, end);
    }

    public static void main(String[] args) {
        System.out.println(new FindPathInputReaderStdIn().FindPath());
    }

}
