import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FindPathInputReaderFile extends AbstractFindPathInputReader{
    String file_name;
    public FindPathInputReaderFile(String file_name){
        this.file_name = file_name;
    }
    public String FindPath(){
        ArrayList<ArrayList<Character>> ArrayListMaze = new ArrayList<ArrayList<Character>>();
        List<Integer> start = new ArrayList<Integer>();
        List<Integer> end = new ArrayList<Integer>();
        try(BufferedReader br = new BufferedReader(new FileReader(file_name))) {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            int y = 0;
            while (line != null) {
                ArrayList<Character> char_list = new ArrayList<Character>();
                for(int x=0; x < line.length(); x++){
                    Character ch = line.charAt(x);
                    char_list.add(ch);
                    if(ch.equals('S')){
                        if(!start.isEmpty()){
                            return "Wrong maze";
                        }
                        start.add(y);
                        start.add(x);
                    }
                    if(ch.equals('X')){
                        if(!end.isEmpty()){
                            return "Wrong maze";
                        }
                        end.add(y);
                        end.add(x);
                    }

                }
                line = br.readLine();
                ArrayListMaze.add(char_list);
                y++;
            }

        } catch (IOException e) {
            return "File not exist";
        }

        if(start.isEmpty() || end.isEmpty()){
            return "Wrong maze";
        }

        return AStar(ArrayListMaze, start, end);
    }



    public static void main(String[] args) {
        System.out.println(new FindPathInputReaderFile("maze.txt").FindPath());
    }
}
